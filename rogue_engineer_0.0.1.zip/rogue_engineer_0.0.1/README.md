## Rogue Engineer
a mod for factorio
https://mods.factorio.com/mod/rogue_engineer

---------------------
# Overview
A roguelite scenario for Factorio.

Choose a starting ability and enter the arena.
Defeat enemies to unlock new abilities and upgrade your current ones.
Survive until the clock runs out.
Compare scores and compete with friends in multiplayer.

---------------------
# Features

---------------------
# Gallery

---------------------
## Companion Mods

---------------------
# Compatibility
There are currently no known mod compatibility issues. To report a compatibility issue, please make a post on the discussion page.

---------------------
# License
Rogue Engineer © 2023 by asher_sky is licensed under Attribution-NonCommercial-ShareAlike 4.0 International.
To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/

---------------------
# Credits
Includes assets from Volume 1 and 2 of The Free Archives © Dreams Circle
